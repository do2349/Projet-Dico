# 🚀 Guide Express - Déploiement en 10 Minutes

## ⚡ Version Ultra-Rapide

### 1️⃣ Supabase (3 min)

1. Va sur [supabase.com](https://supabase.com) → Créer un projet
2. SQL Editor → Nouvelle requête → Colle le fichier `supabase-schema.sql`
3. Settings → API → Copie **URL** et **anon key**

### 2️⃣ Configuration (1 min)

Crée un fichier `.env.local` :
```
NEXT_PUBLIC_SUPABASE_URL=ta_url_ici
NEXT_PUBLIC_SUPABASE_ANON_KEY=ta_key_ici
```

### 3️⃣ Déploiement Vercel (2 min)

**Option A - Avec GitHub :**
1. Crée un repo sur GitHub
2. Push ton code
3. Importe sur Vercel
4. Ajoute les variables d'environnement

**Option B - Direct :**
```bash
npm install -g vercel
cd storydico-app
vercel
```

### 4️⃣ C'est Fait ! 🎉

Ton app est en ligne. Crée un compte et ajoute tes premiers mots !

---

## 🎯 Checklist Rapide

- [ ] Projet Supabase créé
- [ ] Table `words` créée avec le SQL
- [ ] URL et anon key copiées
- [ ] `.env.local` configuré
- [ ] Code push sur GitHub
- [ ] Déployé sur Vercel
- [ ] Variables d'env ajoutées sur Vercel

---

## 💡 Conseils

- **Test local :** `npm install && npm run dev`
- **Vercel CLI :** Plus rapide que GitHub pour un premier test
- **Google Auth :** Optionnel, configure-le plus tard si besoin

---

**Besoin du guide complet ?** → Voir `README.md`
